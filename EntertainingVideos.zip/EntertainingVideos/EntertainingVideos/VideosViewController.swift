//
//  VideosViewController.swift
//  EntertainingVideos
//
//  Created by Pradnya Achari on 04/10/20.
//  Copyright © 2020 Pradnya Achari. All rights reserved.
//

import UIKit
import Alamofire
import AVFoundation

protocol VideoPlayingCellProtocol : NSObjectProtocol {
    func attachPlayerToCell(urlString: String, indexPath : IndexPath)
    func pausePlayerInCell(indexPath : IndexPath)
    func playPlayerInCell(indexPath : IndexPath)
}

class VideosViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, VideoPlayingCellProtocol {
    
    @IBOutlet weak var videoCollection: UICollectionView!
    var videos: [Video] = []
    @IBOutlet weak var loaderView: UIActivityIndicatorView!
    
    lazy var avPlayer : AVPlayer = {
        let player = AVPlayer()
        return player
    }()
    
    lazy var avPlayerLayer : AVPlayerLayer = {
        let layer = AVPlayerLayer(player: self.avPlayer)
        return layer
    }()
    
    class func controller() -> VideosViewController {
        return UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "VideosViewController") as! VideosViewController
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchVideos()
        avPlayer.addObserver(self, forKeyPath: "timeControlStatus", options: [.old, .new], context: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        removePlayerFromCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return videos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        return(collectionView.dequeueReusableCell(withReuseIdentifier: "videoCell", for: indexPath) as! VideoCollectionCell).configure(delegate: self, video: videos[indexPath.row], indexPath: indexPath)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: videoCollection.frame.width, height: videoCollection.frame.height)
    }
    
    func fetchVideos() {
        let request = AF.request("https://videos-woovly.s3.ap-south-1.amazonaws.com/urls/liveStreaming.json")
        request.responseDecodable(of: VideosResponse.self) { (response) in
            guard let videoResponse = response.value else { return }
            self.videos = videoResponse.videos ?? []
            self.videoCollection.reloadData()
        }
    }
    
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        self.removePlayerFromCell()
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let cell = videoCollection.visibleCells[0]
        if let indexPath = videoCollection.indexPath(for: cell) {
            let cell = (cell as! VideoCollectionCell)
            attachPlayerToCell(urlString: cell.video?.url ?? "", indexPath: indexPath)
        }
    }
    
    private func removePlayerFromCell()
    {
        if (self.avPlayerLayer.superlayer != nil)
        {
            self.avPlayerLayer.removeFromSuperlayer()
            self.avPlayer.pause()
            self.avPlayer.replaceCurrentItem(with: nil)
        }
    }
    
    func pausePlayerInCell(indexPath : IndexPath) { self.avPlayer.pause() }
    
    func playPlayerInCell(indexPath : IndexPath) { self.avPlayer.play() }
    
    func attachPlayerToCell(urlString: String, indexPath : IndexPath)
    {
        if let cell = videoCollection.cellForItem(at: indexPath)
        {
            self.removePlayerFromCell()
            if let url = URL(string: urlString) {
                //create player item
                let playerItem = AVPlayerItem(url: url)
                self.avPlayer.replaceCurrentItem(with: playerItem)
                self.avPlayerLayer.videoGravity = .resizeAspect
                self.avPlayerLayer.frame = cell.contentView.frame
                cell.contentView.layer.insertSublayer(avPlayerLayer, at: 1)
                self.avPlayer.play()
            }
        }
    }
    
    override public func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
           if keyPath == "timeControlStatus", let change = change, let newValue = change[NSKeyValueChangeKey.newKey] as? Int, let oldValue = change[NSKeyValueChangeKey.oldKey] as? Int {
               let oldStatus = AVPlayer.TimeControlStatus(rawValue: oldValue)
               let newStatus = AVPlayer.TimeControlStatus(rawValue: newValue)
               if newStatus != oldStatus {
                   DispatchQueue.main.async {[weak self] in
                       if newStatus == .playing || newStatus == .paused {
                        self?.loaderView.stopAnimating()
                       } else {
                        self?.loaderView.startAnimating()
                       }
                   }
               }
           }
       }
}
