//
//  ViewController.swift
//  EntertainingVideos
//
//  Created by Pradnya Achari on 03/10/20.
//  Copyright © 2020 Pradnya Achari. All rights reserved.
//

import UIKit
import GoogleSignIn

class User: Codable {
    let userId: String?  // For client-side use only!
    let idToken: String? // Safe to send to the server
    let fullName: String?
    let givenName: String?
    let email: String?
    
    init(user: GIDGoogleUser) {
        userId = user.userID
        idToken = user.authentication.idToken
        fullName = user.profile.name
        givenName = user.profile.givenName
        email = user.profile.email
    }
}

class ViewController: UIViewController {
    
    @IBOutlet weak var signInButton: GIDSignInButton!
    
    let defaults = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(forName: NSNotification.Name(rawValue: "UserSignedIn"), object: nil, queue: nil) { self.handleSignIn(user: $0.object as! GIDGoogleUser) }
        GIDSignIn.sharedInstance()?.presentingViewController = self
        
        GIDSignIn.sharedInstance()?.restorePreviousSignIn()
    }
    
    func handleSignIn(user: GIDGoogleUser) {
        let currentUser = User(user: user)
        let encoder = JSONEncoder()
        if let encodedUser = try? encoder.encode(currentUser) {
            defaults.set(encodedUser, forKey: "GoogleSignedUser")
        }
        UIApplication.shared.keyWindow?.rootViewController = VideosViewController.controller()
    }
}
