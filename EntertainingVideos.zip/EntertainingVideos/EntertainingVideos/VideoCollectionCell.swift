//
//  VideoCollectionCell.swift
//  EntertainingVideos
//
//  Created by Pradnya Achari on 04/10/20.
//  Copyright © 2020 Pradnya Achari. All rights reserved.
//

import UIKit

class VideoCollectionCell: UICollectionViewCell {
    
    var delegate: VideoPlayingCellProtocol?
    var video: Video?
    var indexPath: IndexPath?
    @IBOutlet weak var titleText: UILabel!
    @IBOutlet weak var likeBtn: UIButton!
    @IBOutlet weak var playBtn: UIButton!
    
    
    func configure(delegate: VideoPlayingCellProtocol?, video: Video?, indexPath: IndexPath) -> Self {
        self.video = video
        self.indexPath = indexPath
        self.delegate = delegate
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { indexPath.row == 0 ? self.delegate?.attachPlayerToCell(urlString: self.video?.url ?? "", indexPath: indexPath) : () }
        titleText.text = video?.title ?? ""
        playBtn.imageView?.image = UIImage(systemName: "pause")
        likeBtn.isSelected = video?.isLiked ?? false
        return self
    }
    
    @IBAction func likeClikced(_ sender: UIButton) {
        likeBtn.isSelected = !likeBtn.isSelected
    }
    
    @IBAction func playClicked(_ sender: UIButton) {
        playBtn.isSelected = !playBtn.isSelected
        playBtn.isSelected ? delegate?.pausePlayerInCell(indexPath: indexPath ?? IndexPath()) : delegate?.playPlayerInCell(indexPath: indexPath ?? IndexPath())
    }
}

class VideosResponse: Codable {
    var videos: [Video]?
}

class Video: Codable {
    var id: Int?
    var title: String?
    var url: String?
    var isLiked: Bool?
}
